import React from "react";
import LoginPortal from "./components/LoginPortal";

function App() {
  return (
    <div>
      <LoginPortal />
    </div>
  );
}

export default App;
